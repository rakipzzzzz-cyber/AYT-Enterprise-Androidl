import type { CapacitorConfig } from '@capacitor/cli';

const config: CapacitorConfig = {
  appId: 'com.ayt.enterprise',
  appName: 'AYT এন্টারপ্রাইজ',
  webDir: 'www',
  bundledWebRuntime: false,
  backgroundColor: '#003732',
  android: {
    allowMixedContent: false
  }
};

export default config;
