# AYT এন্টারপ্রাইজ — Android APK প্রকল্প

এই প্রকল্পে আপনার দেওয়া `AYT এন্টারপ্রাইজ` HTML অ্যাপটি Capacitor Android WebView-এর মধ্যে প্যাকেজ করা হয়েছে। GitHub Actions দিয়ে APK তৈরি হবে।

## GitHub থেকে APK বানানোর নিয়ম (মোবাইল থেকেও করা যাবে)

1. GitHub-এ লগইন করে **New repository** তৈরি করুন। নাম দিন `AYT-Enterprise-Android`। Public বা Private—যেকোনোটি চলবে।
2. এই ZIP ফাইলটি Extract করুন। ভেতরের সব ফাইল ও `.github` ফোল্ডারসহ repository-তে Upload files দিয়ে আপলোড/কমিট করুন। `.github/workflows/build-apk.yml` ফাইলটি অবশ্যই থাকতে হবে।
3. Repository-এর **Actions** ট্যাবে যান। প্রথমবার workflow অনুমতি চাইলে **I understand my workflows, go ahead and enable them** চাপুন।
4. **Build AYT Enterprise APK** workflow নির্বাচন করে **Run workflow** চাপুন। `main`/`master`-এ push করলেও স্বয়ংক্রিয়ভাবে build হবে।
5. Build সফল হলে workflow run খুলুন। নিচের **Artifacts** অংশে `AYT-Enterprise-debug-APK` চাপ দিয়ে ZIP ডাউনলোড করুন।
6. Artifact ZIP Extract করে `app-debug.apk` ফোনে নিন। ফাইলটি চাপুন, প্রয়োজনে Android Settings থেকে ওই অ্যাপ/ব্রাউজারের জন্য **Install unknown apps** অনুমতি দিন, তারপর Install করুন।

## অ্যাপের ডেটা ও অফলাইন ব্যবহার

- HTML অ্যাপটি ফোনের WebView-এর ভেতরে চলে; পণ্য/অর্ডার/হিসাব `localStorage`-এ এই ডিভাইসে সংরক্ষিত হয়।
- মূল স্ক্রিন ও সংরক্ষিত ডেটা ইন্টারনেট ছাড়াই চালানোর জন্য প্যাকেজে রাখা হয়েছে। Google Fonts-এর অনলাইন লিংক বাদ দেওয়া হয়েছে; বাংলা ফন্টের জন্য ফোনের স্থানীয় ফন্ট fallback ব্যবহৃত হবে।
- অ্যাপের সেটিংস থেকে নিয়মিত **ব্যাকআপ নিন** এবং JSON ব্যাকআপ আলাদা জায়গায় রাখুন। অ্যাপের ডেটা ক্লিয়ার বা অ্যাপ আনইনস্টল করলে লোকাল ডেটা হারাতে পারে।
- HTML-এ প্রাথমিক PIN `1234` সেট করা আছে। প্রথমবার ব্যবহারের পর সেটিংস থেকে PIN বদলে নিন। এটি সাধারণ অ্যাপ-লেভেল PIN; পেশাদার এনক্রিপ্টেড অ্যাকাউন্ট সিকিউরিটি নয়।
- এই সংস্করণে স্বয়ংক্রিয় ক্লাউড/একাধিক ডিভাইস সিঙ্ক যুক্ত নেই।

## APK সম্পর্কে

এটি GitHub Actions-এ তৈরি **debug APK**, নিজের ফোনে পরীক্ষা/ইনস্টল করার জন্য। Play Store বা সর্বসাধারণে বিতরণের আগে release signing, app icon, privacy/security review এবং পূর্ণ ডিভাইস টেস্ট দরকার।

## অ্যাপ আইডি

`com.ayt.enterprise`
